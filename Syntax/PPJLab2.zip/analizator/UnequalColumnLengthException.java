
public class UnequalColumnLengthException extends Exception {
	private static final long serialVersionUID = -2210195142311463433L;
}
