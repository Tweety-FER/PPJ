
public class UnequalRowLengthException extends Exception {
	private static final long serialVersionUID = 4302327306749404730L;
}
